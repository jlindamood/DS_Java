public interface Pet {
  public void reward(int numTimes);
  public void punish(int numTimes);
  public void act();
}